//
//  ButtonViewController.swift
//  Project
//
//  Created by cc on 7/3/17.
//  Copyright © 2017 com.chaitali. All rights reserved.
//

import UIKit
class ButtonViewController: UIViewController,UITextFieldDelegate{
    
    
        
       override func viewDidLoad() {
        super.viewDidLoad()
  
    }
   
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}

   
}
